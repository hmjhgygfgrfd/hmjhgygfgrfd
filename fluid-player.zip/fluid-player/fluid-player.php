<?php
/*
Plugin Name: Fluid Player
Plugin URI: https://wordpress.org/support/plugin/fluid-player/
Description: Easily embed a Fluid Player instance on your website by using the fluid-player shortcode.
Version: 2.4.3
Author: Florin Tudor
Author URI: https://www.fluidplayer.com
License: A MIT License
*/

include 'FluidPlayerPlugin.php';

FluidPlayerPlugin::init();
